<?php
session_start();
?>

<html>
<head>
<title>Resultados</title>

<link rel="stylesheet" href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>    
<link href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@300&family=Roboto&display=swap" rel="stylesheet">
</head>
<body>

<div class="caixa">
<img src="img/r.png" width="575px"><br><br>
<h2>Resultados</h2>

<?php
if (!isset($_COOKIE["q1"])) { 
  echo "Erro ao ler o cookie";
  die();
} 

if (!isset($_COOKIE["q2"])) { 
  echo "Erro ao ler a session";
  die();
}
if (!isset($_SESSION["q3"])) { 
    echo "Erro ao ler o session";
    die();
}
if (!isset($_SESSION["q4"])) { 
    echo "Erro ao ler o session";
    die();
}
$q1 = $_COOKIE["q1"];
$q2 = $_SESSION["q2"];
$q3 = $_SESSION["q3"];
$q4 = $_SESSION["q4"];
$respostas = array('Verdadeiro','Líbero','Dentro','B');
$result = array($q1,$q2,$q3,$q4);
$pontuacao = 0;
$a = 0;
while($a < 4){if($result[$a] == $respostas[$a])
    {$pontuacao+=1;}$a+=1;}
   
echo "<br> <p>Você acertou $pontuacao questões. Parabéns!</p>"
?>
</div>
</body>
</html>