<html>
<head>
<title>Questão 1</title>

<link rel="stylesheet" href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>    
<link href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@300&family=Roboto&display=swap" rel="stylesheet">
</head>

<body>
<div class="caixa">
<h2>Questão 1</h2>

<p>Verdadeiro ou falso? "No jogo de vôlei você pode tocar a bola com o pé."</p><br>
<img src="img/q1.png" width="575px"><br><br>
<form method="get" action="questao-02.php">
<input type="radio" id="true" name="q1" value="Verdadeiro">
<label for="verdadeiro">Verdadeiro</label><br>
<input type="radio" id="false" name="q1" value="Falso">
<label for="Falso">Falso</label><br>
<input type="submit" id="proximo" name="proximo" value="Próximo">
</form>
</div>
</body>

</html>