<html>
<head>
<title>Questão 2</title>

<link rel="stylesheet" href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>    
<link href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@300&family=Roboto&display=swap" rel="stylesheet">
</head>

<body>

<!---Script PHP começa aqui--->
<?php
if(!isset($_GET['q1'])){
    echo "Erro ao ler o $_GET";
    die();
}else{
    $cookie_key = "q1";
    $cookie_value = $_GET["q1"];
    setcookie($cookie_key, $cookie_value, time() + (86400 * 30), "/");
}
?>
<!---Script PHP termina aqui--->

<div class="caixa">
<h2>Questão 2</h2>

<p>Dentre os jogadores, apenas um veste o uniforme com as cores "trocadas" para poder se destacar do restante da equipe. Qual jogador é esse?</p><br>
<img src="img/q2.png" width="575px"><br><br>
<form method="get" action="questao-03.php">
<input type="radio" id="capitao" name="q2" value="Capitão">
<label for="verdadeiro">Capitão</label><br>
<input type="radio" id="libero" name="q2" value="Líbero">
<label for="Falso">Líbero</label><br>
<input type="radio" id="levantador" name="q2" value="Levantador">
<label for="Falso">Levantador</label><br>
<input type="radio" id="ponta" name="q2" value="Ponta">
<label for="Falso">Ponta</label><br>
<input type="submit" id="proximo" name="proximo" value="Próximo">
</form>
</div>
</body>

</html>