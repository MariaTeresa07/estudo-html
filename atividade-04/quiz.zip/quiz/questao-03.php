<?php
session_start()
?>

<html>
<head>
<title>Questão 3</title>

<link rel="stylesheet" href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>    
<link href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@300&family=Roboto&display=swap" rel="stylesheet">
</head>

<body>

<!---Script PHP começa aqui--->
<?php
if (!isset($_GET["q2"])) {
  echo "Erro ao ler o GET <BR>";
  die();
}  else {
  $_SESSION["q2"] = $_GET["q2"];
}
?>
<!---Script PHP termina aqui--->

<div class="caixa">
<h2>Questão 3</h2>

<p>Durante uma partida na edição das Olimpíadas de Tóquio, uma equipe pediu para ver o replay da pontuação, e foi exibida essa imagem. A bola está dentro ou fora da quadra?</p><br>
<img src="img/q3.png" width="575px"><br><br>
<form method="get" action="questao-04.php">
<input type="radio" id="dentro" name="q3" value="Dentro">
<label for="verdadeiro">Dentro</label><br>
<input type="radio" id="fora" name="q3" value="Fora">
<label for="Falso">Fora</label><br>
<input type="submit" id="proximo" name="proximo" value="Próximo">
</form>
</div>
</body>

</html>