<?php
session_start()
?>

<html>
<head>
<title>Resultados</title>

<link rel="stylesheet" href="style.css">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>    
<link href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@300&family=Roboto&display=swap" rel="stylesheet">
</head>

<body>
<div class="caixa">
  <h2>Estamos quase lá...</h2>
  <p>Clique abaixo para ver seus resultados!</p>

<!---Script PHP começa aqui--->
<?php
if (!isset($_GET["q4"])) {
  echo "Erro ao ler o GET <BR>";
  die();
}  else {
  $_SESSION["q4"] = $_GET["q4"];
  echo "<br> <a href='resultados.php'>Veja os resultados</a>";
}
?>
<!---Script PHP termina aqui--->

</div>
</body>

</html>